# 🤖 GUÍA DE IMPLEMENTACIÓN PARA AGENTE IA

> **IMPORTANTE**: Este documento contiene instrucciones paso a paso para implementar 
> el Sistema de Competición de Trading en el proyecto Nexus Trading.

---

## 📋 RESUMEN DE CAMBIOS

Este paquete añade un sistema de competición de trading que incluye:

1. **Prompts de competición** (onboarding + sesiones diarias)
2. **Agente Claude CLI mejorado** con persistencia de estado
3. **Monitor de posiciones** para SL/TP automáticos
4. **Orquestador principal** que coordina todo
5. **Configuración YAML** centralizada
6. **Scripts de ejecución**

---

## 📁 ESTRUCTURA DE ARCHIVOS A CREAR/MODIFICAR

```
nexus-trading/
├── config/
│   └── competition.yaml                    # CREAR - Configuración del sistema
│
├── src/
│   ├── agents/
│   │   └── llm/
│   │       ├── prompts/
│   │       │   ├── __init__.py             # MODIFICAR - Añadir exports
│   │       │   ├── competition.py          # CREAR - Prompt único (legacy)
│   │       │   └── competition_v2.py       # CREAR - Sistema de 2 fases
│   │       │
│   │       └── agents/
│   │           ├── __init__.py             # MODIFICAR - Añadir exports
│   │           ├── claude_cli_agent_v2.py  # CREAR - Agente mejorado
│   │           └── competition_agent.py    # CREAR - Agente de competición
│   │
│   └── trading/
│       ├── monitoring/
│       │   ├── __init__.py                 # CREAR - Package init
│       │   └── position_monitor.py         # CREAR - Monitor de posiciones
│       │
│       └── orchestrator.py                 # CREAR - Orquestador principal
│
├── scripts/
│   ├── run_competition.py                  # CREAR - Script principal
│   └── run_competition_demo.py             # CREAR - Demo del sistema
│
└── docs/
    └── FIXES_AND_INTEGRATION.md            # CREAR - Documentación
```

---

## 🔧 INSTRUCCIONES PASO A PASO

### PASO 1: Crear directorio de monitoring

```bash
mkdir -p src/trading/monitoring
```

### PASO 2: Crear __init__.py para monitoring

Crear archivo `src/trading/monitoring/__init__.py`:

```python
"""Módulo de monitoreo de posiciones."""

from .position_monitor import (
    PositionMonitor,
    MonitoredPosition,
    PendingOrder,
    CloseReason,
    MonitorEvent,
)

__all__ = [
    'PositionMonitor',
    'MonitoredPosition', 
    'PendingOrder',
    'CloseReason',
    'MonitorEvent',
]
```

### PASO 3: Copiar archivos nuevos

Copiar los siguientes archivos del ZIP a sus ubicaciones:

| Archivo en ZIP | Destino |
|----------------|---------|
| `src/agents/llm/prompts/competition.py` | `src/agents/llm/prompts/competition.py` |
| `src/agents/llm/prompts/competition_v2.py` | `src/agents/llm/prompts/competition_v2.py` |
| `src/agents/llm/agents/claude_cli_agent_v2.py` | `src/agents/llm/agents/claude_cli_agent_v2.py` |
| `src/agents/llm/agents/competition_agent.py` | `src/agents/llm/agents/competition_agent.py` |
| `src/trading/monitoring/position_monitor.py` | `src/trading/monitoring/position_monitor.py` |
| `src/trading/orchestrator.py` | `src/trading/orchestrator.py` |
| `config/competition.yaml` | `config/competition.yaml` |
| `scripts/run_competition.py` | `scripts/run_competition.py` |
| `scripts/run_competition_demo.py` | `scripts/run_competition_demo.py` |

### PASO 4: Actualizar src/agents/llm/prompts/__init__.py

Reemplazar el contenido con:

```python
"""
Módulo de Prompts para AI Agent.

Incluye:
- Prompts básicos (conservative, moderate)
- Prompt de competición para Claude Code CLI
"""

from .base import SYSTEM_PROMPT_BASE, JSON_OUTPUT_INSTRUCTIONS
from .conservative import CONSERVATIVE_PROMPT
from .moderate import MODERATE_PROMPT
from .competition import (
    COMPETITION_SYSTEM_PROMPT,
    PORTFOLIO_REVIEW_PROMPT,
    build_competition_prompt,
    build_review_prompt,
    COMPETITION_NAME,
    INITIAL_CAPITAL,
)
from .competition_v2 import (
    CompetitionManager,
    CompetitionConfig,
    PerformanceMetrics,
    PositionSummary,
    ONBOARDING_PROMPT,
    build_daily_session_prompt,
    generate_dynamic_ranking,
)

__all__ = [
    # Base
    "SYSTEM_PROMPT_BASE",
    "JSON_OUTPUT_INSTRUCTIONS",
    # Levels
    "CONSERVATIVE_PROMPT",
    "MODERATE_PROMPT",
    # Competition v1
    "COMPETITION_SYSTEM_PROMPT",
    "PORTFOLIO_REVIEW_PROMPT",
    "build_competition_prompt",
    "build_review_prompt",
    "COMPETITION_NAME",
    "INITIAL_CAPITAL",
    # Competition v2
    "CompetitionManager",
    "CompetitionConfig", 
    "PerformanceMetrics",
    "PositionSummary",
    "ONBOARDING_PROMPT",
    "build_daily_session_prompt",
    "generate_dynamic_ranking",
]
```

### PASO 5: Actualizar src/agents/llm/agents/__init__.py

Añadir los nuevos agentes:

```python
"""Agentes LLM disponibles."""

from .claude_agent import ClaudeAgent
from .claude_cli_agent import ClaudeCliAgent
from .claude_cli_agent_v2 import ClaudeCliAgent as ClaudeCliAgentV2
from .competition_agent import CompetitionClaudeAgent

__all__ = [
    'ClaudeAgent',
    'ClaudeCliAgent',
    'ClaudeCliAgentV2',
    'CompetitionClaudeAgent',
]
```

### PASO 6: Actualizar factory.py para usar el nuevo agente

En `src/agents/llm/factory.py`, actualizar el registry:

```python
from .agents.claude_agent import ClaudeAgent
from .agents.competition_agent import CompetitionClaudeAgent

# Registry de implementaciones disponibles
_AGENT_REGISTRY: dict[str, Type[LLMAgent]] = {
    "claude": ClaudeAgent,
    "claude_cli": CompetitionClaudeAgent,  # Usar el nuevo agente de competición
    "competition": CompetitionClaudeAgent,  # Alias
}
```

### PASO 7: Corregir bugs existentes en ai_agent_strategy.py

En `src/strategies/swing/ai_agent_strategy.py`:

**7.1 Eliminar código duplicado (líneas ~56-61):**

BUSCAR:
```python
# Initialize MCP
self.mcp_client = MCPClient()
self.mcp_servers = MCPServers.from_env()

# Initialize MCP
self.mcp_client = MCPClient()
self.mcp_servers = MCPServers.from_env()
```

REEMPLAZAR CON:
```python
# Initialize MCP (una sola vez)
self.mcp_client = MCPClient()
self.mcp_servers = MCPServers.from_env()
```

**7.2 Mover código muerto al __init__ (después del return en context_builder):**

BUSCAR (al final del `__init__` o después del property context_builder):
```python
        # Estado
        self._last_decision = None
```

ASEGURAR que `self._last_decision = None` y `self._last_signals = []` 
estén en el `__init__`, NO después de un `return`.

### PASO 8: Crear directorios de datos

```bash
mkdir -p data/competition/reports
mkdir -p data/competition/sessions
mkdir -p logs
```

### PASO 9: Verificar instalación

Ejecutar para verificar que todo está correcto:

```bash
# Test de imports
python -c "from src.agents.llm.agents.competition_agent import CompetitionClaudeAgent; print('OK')"

# Test de monitor
python -c "from src.trading.monitoring import PositionMonitor; print('OK')"

# Test de orquestador
python -c "from src.trading.orchestrator import CompetitionOrchestrator; print('OK')"
```

---

## 🔌 INTEGRACIÓN CON CÓDIGO EXISTENTE

### Opción A: Usar el nuevo sistema completo (Recomendado)

Ejecutar directamente:

```bash
python scripts/run_competition.py
```

### Opción B: Integrar en StrategyRunner existente

En `src/strategies/runner.py`, añadir soporte para el agente de competición:

```python
from src.agents.llm.agents.competition_agent import CompetitionClaudeAgent

class StrategyRunner:
    def __init__(self, ...):
        # ... código existente ...
        
        # Para estrategia AI con competición
        if strategy_type == "ai_competition":
            self.competition_agent = CompetitionClaudeAgent(
                state_file="./data/competition/agent_state.json"
            )
    
    async def run_ai_competition_strategy(self, context):
        """Ejecuta la estrategia de competición."""
        decision = await self.competition_agent.decide(context)
        return decision.signals
```

### Opción C: Usar solo el monitor con estrategias existentes

```python
from src.trading.monitoring import PositionMonitor, MonitoredPosition

# Crear monitor
monitor = PositionMonitor(
    get_price_func=my_price_fetcher,
    close_position_func=my_closer,
    interval_minutes=5
)

# Añadir posición después de abrir
monitor.add_position(MonitoredPosition(
    symbol="NVDA",
    direction="LONG",
    entry_price=145.0,
    current_price=145.0,
    quantity=10,
    stop_loss=140.0,
    take_profit=160.0,
    entry_time=datetime.now(timezone.utc)
))

# Iniciar monitoreo
await monitor.start()
```

---

## ⚠️ NOTAS IMPORTANTES

### Dependencias

El sistema usa las dependencias existentes del proyecto. No se requieren nuevas instalaciones.

### Claude Code CLI

El agente requiere que `claude` CLI esté instalado y configurado en el sistema.
Verificar con:

```bash
claude --version
```

### Permisos

El agente usa `--permission-mode bypassPermissions` para evitar bloqueos interactivos.

### Estado Persistente

El estado se guarda en `data/competition/`. Si necesitas reiniciar la competición:

```bash
python scripts/run_competition.py --reset
```

### Logs

Los logs se guardan en `logs/competition.log` si está habilitado en la configuración.

---

## 🧪 TESTING

### Test básico del sistema

```bash
python scripts/run_competition_demo.py
```

### Test del agente solo

```python
import asyncio
from src.agents.llm.agents.competition_agent import CompetitionClaudeAgent

async def test():
    agent = CompetitionClaudeAgent()
    
    # Primera vez: hace onboarding
    await agent.ensure_onboarded()
    
    print(f"Day: {agent.competition_day}")
    print(f"Metrics: {agent.metrics}")

asyncio.run(test())
```

### Test del monitor

```python
import asyncio
from src.trading.monitoring import PositionMonitor, MonitoredPosition
from datetime import datetime, timezone

async def mock_price(symbol):
    return 150.0

async def mock_close(symbol, reason, price):
    print(f"Closing {symbol}: {reason} @ {price}")
    return True

async def test():
    monitor = PositionMonitor(
        get_price_func=mock_price,
        close_position_func=mock_close,
        interval_minutes=1
    )
    
    monitor.add_position(MonitoredPosition(
        symbol="TEST",
        direction="LONG",
        entry_price=145.0,
        current_price=145.0,
        quantity=10,
        stop_loss=140.0,
        take_profit=155.0,
        entry_time=datetime.now(timezone.utc)
    ))
    
    # Verificar inmediatamente
    await monitor.check_now()
    
    print(f"Stats: {monitor.get_stats()}")

asyncio.run(test())
```

---

## 📊 FLUJO DE EJECUCIÓN

```
┌─────────────────────────────────────────────────────────────┐
│                    EJECUCIÓN DIARIA                         │
└─────────────────────────────────────────────────────────────┘

$ python scripts/run_competition.py

        │
        ▼
┌───────────────────┐
│ 1. Cargar config  │
│    competition.yaml│
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ 2. Inicializar    │
│    orquestador    │
│    + agente       │
│    + monitor      │
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ 3. Construir      │
│    contexto       │
│    (portfolio,    │
│    mercado, etc)  │
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ 4. Llamar a       │◄─── Claude analiza, usa web search,
│    Claude CLI     │     genera JSON con decisiones
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ 5. Procesar       │
│    señales        │
│    - CLOSE        │
│    - LONG/SHORT   │
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ 6. Monitor        │◄─── Corre en background cada 5 min
│    activo         │     verificando SL/TP
└─────────┬─────────┘
          │
          │ (Ctrl+C o fin del día)
          ▼
┌───────────────────┐
│ 7. Fin del día    │
│    - Métricas     │
│    - Reporte      │
│    - Persistir    │
└───────────────────┘
```

---

## ✅ CHECKLIST DE IMPLEMENTACIÓN

- [ ] Crear directorio `src/trading/monitoring/`
- [ ] Crear `src/trading/monitoring/__init__.py`
- [ ] Copiar `position_monitor.py`
- [ ] Copiar `orchestrator.py`
- [ ] Copiar archivos de prompts
- [ ] Copiar archivos de agents
- [ ] Actualizar `prompts/__init__.py`
- [ ] Actualizar `agents/__init__.py`
- [ ] Actualizar `factory.py`
- [ ] Corregir bugs en `ai_agent_strategy.py`
- [ ] Copiar `config/competition.yaml`
- [ ] Copiar scripts de ejecución
- [ ] Crear directorios de datos
- [ ] Verificar imports
- [ ] Ejecutar test básico

---

## 🆘 SOLUCIÓN DE PROBLEMAS

### Error: "Module not found"

Verificar que todos los `__init__.py` están creados correctamente.

### Error: "Claude CLI not found"

Instalar Claude Code CLI:
```bash
npm install -g @anthropic-ai/claude-code
```

### Error: "Timeout"

Aumentar `timeout_seconds` en la configuración o en el código:
```yaml
agent:
  timeout_seconds: 300  # 5 minutos
```

### El agente no usa web search

Verificar que el prompt incluye instrucciones de búsqueda.
El agente debería buscar automáticamente si el contexto lo requiere.

---

**FIN DE LA GUÍA DE IMPLEMENTACIÓN**
