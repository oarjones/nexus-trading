# 🔧 Correcciones y Mejoras para Nexus Trading

## 🏗️ Nueva Arquitectura: Sistema de Competición

### Flujo de Dos Fases

```
┌─────────────────────────────────────────────────────────────────┐
│                    FASE 1: ONBOARDING                           │
│                    (Una sola vez)                               │
├─────────────────────────────────────────────────────────────────┤
│  • Reglas de la competición                                     │
│  • Límites de trading                                           │
│  • Criterios de evaluación                                      │
│  • Filosofía de trading                                         │
│  • El agente responde "READY"                                   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                 FASE 2: SESIONES DIARIAS                        │
│                 (Cada día de trading)                           │
├─────────────────────────────────────────────────────────────────┤
│  • Métricas actuales (retorno, sharpe, drawdown)               │
│  • Ranking dinámico vs otros competidores                       │
│  • Posiciones abiertas con P&L                                  │
│  • Contexto de mercado del día                                  │
│  • Historial de trades recientes                                │
│  • El agente analiza y genera señales                           │
└─────────────────────────────────────────────────────────────────┘
```

### Ventajas de Esta Arquitectura

| Aspecto | Antes | Ahora |
|---------|-------|-------|
| **Tokens por sesión** | ~2500 (prompt completo) | ~1200 (solo contexto) |
| **Consistencia** | Variable | Reglas fijas en memoria |
| **Motivación** | Genérica | Ranking competitivo |
| **Métricas** | Sin tracking | Métricas en tiempo real |
| **Persistencia** | No | Estado guardado en JSON |

---

## 📁 Archivos Creados

```
src/agents/llm/prompts/
├── competition.py          # Versión inicial (prompt único)
└── competition_v2.py       # ⭐ Nueva versión (onboarding + daily)

src/agents/llm/agents/
├── claude_cli_agent.py     # Original
├── claude_cli_agent_v2.py  # Mejorado con timeout
└── competition_agent.py    # ⭐ Agente completo de competición

scripts/
└── run_competition_demo.py # ⭐ Demo del flujo completo
```

---

## 🚀 Cómo Usar

### Opción 1: Agente de Competición (Recomendado)

```python
from src.agents.llm.agents.competition_agent import CompetitionClaudeAgent

# Crear agente (carga estado previo si existe)
agent = CompetitionClaudeAgent(
    timeout_seconds=180.0,
    state_file="./data/competition_state.json"
)

# Primera vez: onboarding automático
# Siguientes veces: salta directo a sesión
decision = await agent.decide(context)

# Después de cerrar trades, actualizar métricas
agent.update_trade_results([
    {"symbol": "NVDA", "pnl_pct": 5.2}
])

# Al final del día
agent.advance_day(daily_return=0.8)
```

### Opción 2: Solo Prompts (Para Integrar en tu Agente Existente)

```python
from src.agents.llm.prompts.competition_v2 import (
    CompetitionManager,
    ONBOARDING_PROMPT
)

# Crear manager
manager = CompetitionManager()

# Primera sesión: enviar onboarding
if not manager.is_onboarded:
    send_to_claude(ONBOARDING_PROMPT)
    manager.confirm_onboarding()

# Sesiones siguientes: solo contexto diario
daily_prompt = manager.get_daily_prompt(
    current_date=datetime.now(),
    portfolio_value=26000,
    cash_available=18000,
    positions=[...],
    market_regime="BULL",
    vix_level=15.5,
    spy_change=0.5,
    trades_today=1
)
```

---

## 📊 Estructura del Prompt Diario

El prompt diario incluye:

```
╔═══════════════════════════════════════════════════════╗
║  📅 SESIÓN DE TRADING - DÍA X DE LA COMPETICIÓN       ║
╚═══════════════════════════════════════════════════════╝

🏆 LEADERBOARD EN VIVO:
   #1  QuantumEdge AI     +12.5%  Score: 185.2  ↑
   #2  DeepAlpha v3       +9.8%   Score: 162.1  →
   ...
   ★ #8  TÚ (NEXUS-AI)    +5.0%   Score: 98.5   ↑
   ...
   📈 Para subir al #7: necesitas +0.8%

📊 TU ESTADO ACTUAL:
   Valor total: $26,250
   Rendimiento: +5.00%
   Sharpe: 1.45
   Max DD: -2.1%
   Win Rate: 66.7%

📦 POSICIONES ABIERTAS:
   🟢 NVDA (LONG): $140.50 → $145.20 (+3.34%)
   🔴 AAPL (LONG): $178.00 → $175.50 (-1.40%)

🌍 CONTEXTO DE MERCADO:
   Régimen: BULL | VIX: 15.8 | SPY: +0.45%

🎯 RESPONDE CON JSON...
```

---

## ⚠️ Bugs a Corregir en tu Código

### 1. AIAgentStrategy - Código duplicado

```python
# Líneas 56-61: ELIMINAR la segunda inicialización
self.mcp_client = MCPClient()
self.mcp_servers = MCPServers.from_env()
# ↓ BORRAR ESTAS LÍNEAS ↓
self.mcp_client = MCPClient()  # DUPLICADO
self.mcp_servers = MCPServers.from_env()  # DUPLICADO
```

### 2. AIAgentStrategy - Código muerto

```python
# Líneas 97-98: Mover al __init__
@property
def context_builder(self):
    ...
    return self._context_builder
    # ↓ ESTE CÓDIGO NUNCA SE EJECUTA ↓
    self._last_decision = None  # MOVER AL __init__
```

---

## 🧪 Ejecutar Demo

```bash
cd nexus-trading
python scripts/run_competition_demo.py
```

Primera ejecución:
1. Hace onboarding (explica reglas)
2. Ejecuta sesión diaria
3. Muestra ranking y métricas
4. Guarda estado

Siguientes ejecuciones:
1. Carga estado previo
2. Salta onboarding
3. Continúa desde el día actual

---

## 💡 Ideas Futuras

### Modos de Competición

```python
COMPETITION_MODES = {
    "sprint": {"days": 5, "aggressive": True},
    "marathon": {"days": 30, "conservative": True},
    "tournament": {"days": 10, "bracket": True}
}
```

### Eventos Especiales

```python
# Añadir al prompt diario eventos aleatorios
SPECIAL_EVENTS = [
    "⚡ BONUS: +50 pts si cierras con >2% hoy",
    "🎯 CHALLENGE: Opera solo en tech esta sesión",
    "⚠️ SURVIVAL: Evita cualquier pérdida hoy"
]
```

### Competidores con Personalidad

```python
# Competidores más "reales"
COMPETITORS = {
    "QuantBot-7": {"style": "momentum", "strength": "tech"},
    "ValueHunter": {"style": "value", "strength": "defensive"},
    "RiskTaker_AI": {"style": "aggressive", "weakness": "drawdowns"}
}
```
