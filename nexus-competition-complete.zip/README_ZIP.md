# 🏆 Nexus Trading Competition System

## Contenido del ZIP

```
├── config/
│   └── competition.yaml           # Configuración del sistema
│
├── src/
│   ├── agents/llm/
│   │   ├── prompts/
│   │   │   ├── __init__.py        # Exports actualizados
│   │   │   ├── competition.py     # Prompt único (v1)
│   │   │   └── competition_v2.py  # Sistema onboarding + diario
│   │   │
│   │   └── agents/
│   │       ├── __init__.py        # Exports actualizados
│   │       ├── claude_cli_agent_v2.py
│   │       └── competition_agent.py
│   │
│   └── trading/
│       ├── monitoring/
│       │   ├── __init__.py
│       │   └── position_monitor.py
│       │
│       └── orchestrator.py
│
├── scripts/
│   ├── run_competition.py         # Script principal
│   └── run_competition_demo.py    # Demo
│
└── docs/
    ├── IMPLEMENTATION_GUIDE.md    # ⭐ LEER PRIMERO
    └── FIXES_AND_INTEGRATION.md   # Documentación detallada
```

## 🚀 Instalación Rápida

### Para el Agente IA:

1. Descomprime este ZIP en el directorio raíz del proyecto nexus-trading
2. Lee `docs/IMPLEMENTATION_GUIDE.md` para instrucciones completas
3. Ejecuta los pasos del checklist

### Comando para agente:

```
Descomprime el archivo nexus-competition-complete.zip en el proyecto.
Sigue las instrucciones en docs/IMPLEMENTATION_GUIDE.md paso a paso.
Asegúrate de crear el directorio src/trading/monitoring/ si no existe.
Verifica los imports después de copiar los archivos.
```

## ✅ Verificación

```bash
# Verificar imports
python -c "from src.agents.llm.agents import CompetitionClaudeAgent; print('OK')"
python -c "from src.trading.monitoring import PositionMonitor; print('OK')"
python -c "from src.trading.orchestrator import CompetitionOrchestrator; print('OK')"

# Ejecutar demo
python scripts/run_competition_demo.py
```

## 📖 Documentación

- **IMPLEMENTATION_GUIDE.md**: Guía paso a paso para implementar
- **FIXES_AND_INTEGRATION.md**: Explicación del sistema y bugs a corregir
